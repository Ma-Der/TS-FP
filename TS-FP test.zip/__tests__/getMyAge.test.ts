import { getMyAge } from '../getMyAge';

// czy wiek jest ten sam niezależnie od typu inputa


//czy wyrzuca błąd kiedy nie podamy żadnego argumentu

//czy wyrzuca błąd kiedy w input podamy NaN

// czy wyrzuca błąd kiedy podamy pusty string

// czy wyrzuca błąd kiedy podamy date mniejszą niż 1900

// czy wyrzuca błąd kiedy podamy datę większą niż aktualna



describe("getMyAge works properly", () => {

    test("when age is the same independently of input (string, number or Date)", () => {});
   });
   
describe("getMyAge properly handles error", () => {   
    test("when there is no in input", () => {});
   
    test("when in input is NaN", () => {});
   
    test("when in input is empty string", () => {});
   
    test("when input is less then 1900", () => {});
   
    test("when input is later than the actual date", () => {});
});

