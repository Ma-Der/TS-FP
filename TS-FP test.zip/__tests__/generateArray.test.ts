import { generateArrayWithRandomNumbers, generateArrayOfArrays } from '../generateArray';

//czy zwraca error gdy liczby nie są całkowite
//czy zwraca error gdy zmienna howManyNumbers jest mniejsza od zera
//czy zwraca error gdy któraś ze zmiennych jest typu NaN


//czy zwraca error gdy zmienna howManyArrays jest mniejsza od zera

describe('generateArrayWithNumbers properly works', () => {
    test('when numbers are randomly placed in array', () => {
        const exampleInput = generateArrayWithRandomNumbers(5, 1, 5);
        const notRandomResult = [1,2,3,4,5];
        expect(exampleInput).not.toEqual(notRandomResult);
    });

    test('when in array are amount of numbers that was given', () => {
        const howManyNumbers = 5;
        const exampleInput = generateArrayWithRandomNumbers(howManyNumbers, 1, 10);

        expect(exampleInput.length).toBe(howManyNumbers);
    });
});

describe('generateArrayWithNumbers properly handles error', () => {
    test('when min and max value are not integers', () => {
        const minValue = 1.3;
        const maxValue = 3.6;
        () => expect(generateArrayWithRandomNumbers(4, minValue, 5)).toThrowError("Min value must be an integer.");
        () => expect(generateArrayWithRandomNumbers(4, 2, maxValue)).toThrowError("Max value must be an integer.");
    });

    test('when howManyNumbers argument is less than zero', () => {

    });

    test('when one of the variables is NaN', () => {

    });
});

describe('Generate Array of Arrays properly works', () => {
    test('when there is as many arrays that were given in howManyArrays variable', () => {
        const howManyArrays = 3;
        const exampleInput = generateArrayOfArrays(howManyArrays, 3, 5, 100);

        expect(exampleInput.length).toBe(howManyArrays);
    });
});

describe('Generate Array of Arrays properly handles error', () => {
    test('when howManyArrays variable is less than zero', () => {

    });
});




