import { mapFnR, filterFnR, everyFnR, someFnR } from '../masterReduce';

describe('mapFnR function works properly', () => {
    test('when ', () => {

    });
});