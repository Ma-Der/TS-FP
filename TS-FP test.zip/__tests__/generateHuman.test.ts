import { generateHuman } from '../generateHuman';

// czy wybrane imie jest losowe

// czy wybrane nazwisko jest losowe

// czy email składa się z wybranego imienia i nazwiska np. piotr.nowak@mail.com

// czy wybrany kraj zawiera się w ['PL', 'UK', 'USA']

// czy wiek zawiera się w przedziale 18-85

// czy nr telefonu ma 9 cyfr



describe("generateHuman function works properly", () => {
    test("when name is generated randomly", () => {

    });
   
    test("when surname is generated randomly", () => {

    });
   
    test("when email includes randomly generated name and surname", () => {

    });
   
    test('when randomly picked country is from array ["PL", "UK", "USA"]', () => {

    });
   
    test("when age is inbetween 18-85", () => {

    });
   
    test("when phone number has 9 digits", () => {
        
    });
});
