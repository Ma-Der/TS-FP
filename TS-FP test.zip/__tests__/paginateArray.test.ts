import { paginateArray } from '../paginateArray';

// czy wyrzuca błąd kiedy array jest pusty

// czy wyrzuca błąd kiedy któryś z argumentów jest NaN

// czy wyrzuca błąd jeśli wartości settings nie są większe od zera

// czy wyrzuca błąd jeśli podamy liczbę strony większą niż faktycznie jest stron przy danych ustawieniach



// czy zwraca maksymalnie tyle elementów na strone ile podane jest w settings

// czy dzieli na strony dane elementy po kolei



describe("paginateArray works properly", () => {
 test("when elements are paginated not in random order", () => {

 });

 test("when on page is number of elements that was submitted in settings", () => {

 });
});

describe("paginateArray handles errors properly", () => {
 test("when input array is empty", () => {

 });

 test("when one of the settings arguments is NaN", () => {

 });

 test("when settings values are not greater than zero", () => {

 });

 test("when number of pages in settings is greater than actual pages", () => {
     
 });
});