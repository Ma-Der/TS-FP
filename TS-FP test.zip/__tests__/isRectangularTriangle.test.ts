import { isRectangularTriangle } from '../isRectangularTriangle';


//czy wyrzuca błąd jeśli, któryś z argumentów jest NaN

//czy wyrzuca błąd jeśli suma krótszych boków jest mniejsza bądź równa najdłuższemu bokowi

//czy wyrzuca błąd jeśli któryś z argumentów jest mniejszy lub równy 0



// czy zwraca true kiedy z danych długości boków można zbudować trójkąt prostokątny

// czy zwraca false kiedy z danych długości boków nie można zbudować trójkąta prostokątnego



describe("isRectangularTriangle function works properly", () => {
    test("when returns true if from given lengths can build rectangular triangle", () => {

    });
   
    test("when returns false if from given lengths you cannot build rectangular triangle", () => {

    });
});
   
   
   
describe("isRectangularTriangle handles errors properly", () => {
    test("when one of the arguments is NaN", () => {

    });
   
    test("when sum of shorter sides is less or equal to the longest side", () => {

    });
   
    test("when one of the argument is not greater than zero", () => {
        
    });
});

